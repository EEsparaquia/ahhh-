package com.parser.interfaces;

import java.io.File;
import com.parser.beans.ProcessedCollection;

public interface IImageNameProcessor {

	public  ProcessedCollection process(File fileFolder ,String group,String tag) throws Exception;
	
}
