package com.parser.processors;

import java.io.File;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.parser.beans.ProcessedCollection;
import com.parser.beans.Type1;
import com.parser.beans.Type2;
import com.parser.interfaces.IImageNameProcessor;

public class ImageNameParser implements IImageNameProcessor {
	
	private static final String PHOTO_PATTERN = "([A-Za-z]+)-(\\d\\d\\d\\d)-(\\d)-([A-Z])(\\.[A-Za-z]+)";
	private Pattern photoPattern = Pattern.compile(PHOTO_PATTERN);
	
	private static final String IMAGE_PATTERN = "sg(\\d\\d\\d\\d)A[-|\\+](\\d\\d\\.\\d\\d)[A-Z][-|\\+](\\d\\d)-([A-Za-z]+)(\\.[a-z]+)";
	private Pattern imagePattern = Pattern.compile(IMAGE_PATTERN);
	
	public ImageNameParser()
	{
	}
	
	
	private Type1 extractType1Info(File imageFile) throws Exception {
		
		if (imageFile!=null && imageFile.isFile()) {
			Matcher m = imagePattern.matcher(imageFile.getName());
			if (m.find()) {
				Type1 type1Obj = new Type1();
				type1Obj.setFileName(imageFile.getName());
				type1Obj.setSubGroup(m.group(1));
				type1Obj.setValue_A(m.group(2));
				type1Obj.setValue_B(m.group(3));
				type1Obj.setSubType(m.group(4));
				type1Obj.setPath(imageFile.getAbsolutePath());
				return type1Obj;
			} else {
				return null;
			}

		} else {
			return null;
		}
	}
	
	private Type2 extractType2Info(File imageFile) {

		if (imageFile!=null && imageFile.isFile()) {

			Matcher patternMatcher = photoPattern.matcher(imageFile.getName());

			if (patternMatcher.find()) {
				Type2 type2Obj = new Type2();
				type2Obj.setFileName(imageFile.getName());
				type2Obj.setGroup(patternMatcher.group(1));
				type2Obj.setSubGroup(patternMatcher.group(2));
				type2Obj.setSequenceNumber(patternMatcher.group(3));
				type2Obj.setPhotoAtribute(patternMatcher.group(4));
				type2Obj.setPath(imageFile.getAbsolutePath());
				return type2Obj;
			} 
		} 
		return null;
	}
	
	private File[] getFiles(File folder ,String group,String tag){
		
		ArrayList<File> fileList= new ArrayList<File>();
		
		if(folder!=null)
		{
			ArrayList<File> directories = new ArrayList<File>();
			directories.add(folder);
			
			while(!directories.isEmpty() && (folder = directories.remove(0))!=null)
			{
				File[] listOfFiles = folder.listFiles();
				if(listOfFiles!=null)
				{
					for ( File file : listOfFiles) {
						if(file.isFile()){

							if((group!=null && file.getName().contains(group)) || (tag!=null && file.getName().contains(tag))){
								System.out.println(file.getName());
								fileList.add(file);
							}

						}else if(file.isDirectory()){
							directories.add(file);					 
						}
					}
				}
				
			}
		}
		return fileList.toArray(new File[]{});
		
	}
	
	public ProcessedCollection process(File folder ,String group,String tag) throws Exception{
		
		Type1 type1 = null;
		Type2 type2 = null;

		ProcessedCollection collection = new ProcessedCollection();
		File[] imageFiles = getFiles(folder, group, tag);
		for (File imageFile : imageFiles) {
			type1 = extractType1Info(imageFile);
			if(type1!=null)
			{
				collection.addType1(type1);
			}
			else
			{
				type2 = extractType2Info(imageFile);
				collection.addType2(type2);
			}
				
		}
		return collection;
	}


}
