package com.parser.beans;

import java.util.ArrayList;

public class ProcessedCollection {

	private ArrayList<Type1> type1Collection = new ArrayList<Type1>();
	private ArrayList<Type2> type2Collection = new ArrayList<Type2>();

	public ArrayList<Type1> getType1Collection() {
		return type1Collection;
	}
	
	public ArrayList<Type2> getType2Collection() {
		return type2Collection;
	}
	
	public void addType1(Type1 type1){
		type1Collection.add(type1);
	}

	public void addType2(Type2 type2){
		type2Collection.add(type2);
	}
	
	public boolean hasType1Collection()
	{
		return (!type1Collection.isEmpty());
	}
	
	public boolean hasType2Collection()
	{
		return (!type2Collection.isEmpty());
	}

}
