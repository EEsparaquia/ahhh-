package com.parser.beans;

public class Type1 {

	private  String fileName ="";
	private  String subGroup ="";
	private  String value_A  ="";
	private  String value_B  ="";
	private  String subType = "";
	private  String path="";
	
	public Type1 (){
		
	}
	
	public Type1(String fileName, String subGroup,
			String value_A, String value_B, String subType, String path) {
		super();
		this.fileName = fileName;
		this.subGroup = subGroup;
		this.value_A = value_A;
		this.value_B = value_B;
		this.subType = subType;
		this.path = path;
	}
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getSubGroup() {
		return subGroup;
	}
	public void setSubGroup(String subGroup) {
		this.subGroup = subGroup;
	}

	public String getValue_A() {
		return value_A;
	}
	public void setValue_A(String value_A) {
		this.value_A = value_A;
	}
	public String getValue_B() {
		return value_B;
	}
	public void setValue_B(String value_B) {
		this.value_B = value_B;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("----- FileName : " + fileName +" -----\n");
		sb.append("SubGroup : "+ subGroup +"\n");
		sb.append("Value A : "+ value_A +"\n");
		sb.append("Value B : "+ value_B +"\n");
		sb.append("SubType : "+ subType +"\n");
		sb.append("Path : "+ path +"\n");
		sb.append("-------------------------------------\n");
		return sb.toString();
	}
}
