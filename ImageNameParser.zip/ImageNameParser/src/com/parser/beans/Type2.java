package com.parser.beans;

public class Type2 {

	private String fileName= "";
	private String group ="";
	private String subGroup ="";
	private String sequenceNumber  ="";
	private String photoAttribute  ="";
	private String path="";
	
	public Type2(){
		
	}
	
	public Type2(String fileName, String group, String subGroup,
			String sequenceNumber, String photoaAtribute,
			String exetensionType, String path) {
		super();
		this.fileName = fileName;
		this.group = group;
		this.subGroup = subGroup;
		this.sequenceNumber = sequenceNumber;
		this.photoAttribute = photoaAtribute;
		this.path = path;
	}
	
	public String getFileName() {
		return fileName;
	}
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getGroup() {
		return group;
	}
	
	public void setGroup(String group) {
		this.group = group;
	}
	
	public String getSubGroup() {
		return subGroup;
	}
	
	public void setSubGroup(String subGroup) {
		this.subGroup = subGroup;
	}
	
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	
	public String getPhotoAtribute() {
		return photoAttribute;
	}

	public void setPhotoAtribute(String photoAtribute) {
		this.photoAttribute = photoAtribute;
	}

	public String getPath() {
		return path;
	}
	
	public void setPath(String path) {
		this.path = path;
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("----- FileName : " + fileName+" -----\n");
		sb.append("Group : "+ group +"\n");
		sb.append("SubGroup : "+ subGroup +"\n");
		sb.append("SequenceNumber : "+ sequenceNumber +"\n");
		sb.append("PhotoAtribute : "+ photoAttribute +"\n");
		sb.append("Path : "+ path +"\n");
		sb.append("-------------------------------------\n");
		return sb.toString();
	}
	
}
