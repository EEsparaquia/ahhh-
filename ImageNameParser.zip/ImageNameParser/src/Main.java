import java.io.File;
import java.util.ArrayList;

import com.parser.beans.ProcessedCollection;
import com.parser.beans.Type1;
import com.parser.beans.Type2;
import com.parser.interfaces.IImageNameProcessor;
import com.parser.processors.ImageNameParser;


public class Main  {

	public static void main(String[] args) throws Exception {

		String group = "exterior";
		String tag  = "Photo";
		File generalPath = new File("C:/resources_files");
		
		IImageNameProcessor imageNameProcessor = new ImageNameParser() ;
		ProcessedCollection processedData=imageNameProcessor.process(generalPath,group,tag);
		
		if(processedData.hasType1Collection())
		{
			System.out.println("\n====== Type 1 Images Information ===========\n");
			for(Type1 data: processedData.getType1Collection())
			System.out.println(data.toString());
			
			System.out.println("\n===========================================");
		}
		
		if(processedData.hasType2Collection())
		{
			System.out.println("\n====== Type 2 Images Information ===========\n");
			for(Type2 data: processedData.getType2Collection())
				System.out.println(data.toString());
			System.out.println("\n===========================================");
		}
		
		
	}

}
